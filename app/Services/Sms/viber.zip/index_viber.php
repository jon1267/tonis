<?php

require_once 'Viber.php';
$viber = new Viber();

$phone = '79803880336'; //$phone = '79065662348';
$text = 'Test Viber message. Тестовое вайбер сообщение';
$out = $viber->message($phone, $text);

echo '<pre>'.print_r($out,1).'</pre>';