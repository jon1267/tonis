<?php

/**
 * Класс для отправки Viber сообщений (https://my2.viber.net.ua/)
 *
 * Class Viber
 */
class Viber
{
    const API_TOKEN = '$2y$10$LUJzEx.1uzEPlwauV3cA9uJbOomE.fpUFxBfy0Eiy2eJwvlJhdAXi';
    const API_VIBER = 'https://my2.viber.net.ua/api/v2/viber/dispatch';

    public function message(string $phone, string $text)
    {
        $data = [
            'name' => 'PdParis Viber message',
            'recipients' => $phone,
            'sender' => 'PDParis Ru',
            'message'=> $text,
            'sms_sender' => 'Pdp-shop',
            'sms_message' => $text,
        ];

        return $this->request($data);
    }

    private function request(array $data=[])
    {
        $ch = curl_init(self::API_VIBER);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Accept: application/json", "Accept-Charset: utf-8",
            "Authorization: Bearer " . self::API_TOKEN,
        ]);

        curl_setopt($ch, CURLOPT_POSTFIELDS,  $data);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response); //$response;
    }
}